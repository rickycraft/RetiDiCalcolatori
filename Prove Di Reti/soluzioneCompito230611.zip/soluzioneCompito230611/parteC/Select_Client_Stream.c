// client stream

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define DIM_BUFF 256
#define DIM_CF 17

int main(int argc, char * argv[]) {
	int sd, nread, readRes;
	struct hostent * host;
	struct sockaddr_in serverAddress;
	char richiesta[DIM_BUFF]; // stringa per la trasmissione su socket stream
	int port, lengthVotante;
	// buffer di dimensione tale da contenere CF, nome, cognome e 2 separatori (\t) e il terminatore (\0)
	char buff[DIM_CF + DIM_BUFF * 2 + 23];

	// CONTROLLO ARGOMENTI PROGRAMMA

	if (argc != 3) {
		printf("\nError: %s serverAddress serverPort", argv[0]);
		exit(1);
	}

	// Inizializzazione indirizzo server
	memset((char *) &serverAddress, 0, sizeof(struct sockaddr_in));
	serverAddress.sin_family = AF_INET;

	// Estraggo l'indirizzo del server con gethostbyname che
	// restituisce direttamente gli indirizzi in formato di rete
	host = gethostbyname(argv[1]);

	if (host == NULL) {
		printf("%s not found in /etc/hosts\n", argv[1]);
		exit(2);
	}
	// Controllo secondo argomento -> numero di porta intero
	nread = 0;
	while (argv[2][nread] != '\0') {
		if (argv[2][nread] < '0' || argv[2][nread] > '9') {
			printf("Secondo argomento non intero\n");
			exit(2);
		}
		nread++;
	}
	port = atoi(argv[2]);
	if (port < 1024 || port > 65535) {
		printf("Porta scorretta, range numerico sbagliato");
		exit(3);
	}
	serverAddress.sin_port = htons(port);
	serverAddress.sin_addr.s_addr = ((struct in_addr*) (host->h_addr))->s_addr;

	printf("Client avviato\n");
	/*CORPO DEL CLIENT */
	printf("Richieste di esecuzione del client\n");
	printf("Input, EOF per terminare: ");

	// Soluzione con una sola connessione per tutta la sessione cliente

	// CREAZIONE E CONNESSIONE SOCKET (BIND IMPLICITA)

	sd = socket(AF_INET, SOCK_STREAM, 0);
	if (sd < 0) {
		perror("apertura socket ");
		exit(3);
	}
	printf("Creata la socket sd=%d\n", sd);

	if (connect(sd, (struct sockaddr *) &serverAddress, sizeof(struct sockaddr))
			< 0) {
		perror("Errore in connect");
		exit(4);
	}
	printf("Connect ok\n");

	printf("Richieste fino alla file del file di input\n");
	printf("\nInserisci qualunque stringa per la lista non votanti: ");
	/* Per ogni richiesta:
	 * 1) Invio la richiesta.
	 * 2) Ricevo la lista delle stringhe dei non votanti.
	 *    Per ciascuna stringa effettua 2 letture:
	 *    a) legge la lunghezza della stringa;
	 *    b) legge la stringa vera e propria.
	 *    Una lunghezza di stringa zero (0) viene utilizzata
	 *    per segnalare la fine della lista.
	 *
	 */
	while (gets(richiesta)) {
		// INVIO RICHIESTA AL SERVER...Scrittura su socket
		// Se l'invio fallisce, esco.
		if (write(sd, richiesta, 1) < 0) {
			perror("write");
			break;
		}
		printf("Richiesta %s inviata...\n", richiesta);

		// Ricevo la lunghezza della stringa.
		// Lunghezza zero usata per segnalare la fine della lista.
		lengthVotante = 0;
		printf("Ecco la lista dei non votanti:\n", lengthVotante);
		// Se la lettura fallisce, esco.
		while ((readRes = read(sd, &lengthVotante, sizeof(int))) > 0) {
			lengthVotante = ntohl(lengthVotante);
			if (lengthVotante > 0) {
				/* Per ogni votante leggo un'unica stringa con CF, nome e cognome,
				 * di lunghezza lenghtVotante.
				 * Si possono aggiungere controlli ulteriori sulla lettura, omessi
				 * per migliore leggibilita' del codice.
				 */
				read(sd, buff, lengthVotante);
				// aggiungo il terminatore di stringa, non passato sullo stream
				buff[lengthVotante] = '\0';
				// stampo il non votante ricevuto
				printf("Ho ricevuto: %s\n", buff);
			} else
				break; // lenghtVotante == 0, esco dal ciclo di lettura
		}
		printf("\nInserisci qualunque stringa per la lista non votanti: ");
	} // if
	printf("\nSelect_Client_Stream: termino...\n");
	close(sd);
	exit(0);
}
