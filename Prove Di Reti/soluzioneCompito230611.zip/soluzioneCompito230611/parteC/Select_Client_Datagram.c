// client datagram

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>

#define DIM_BUFF 256
int main(int argc, char * argv[]) {
	struct hostent *host;
	struct sockaddr_in clientAddress, serverAddress;
	int sd, len, num, port;
	char richiesta[DIM_BUFF]; // rappresenta la stringa da trasmettere via socket datagram
	/* CONTROLLO ARGOMENTI */
	// char risposta[DIM_BUFF]; // rappresenta una stringa di risposta da parte del server
	int risposta;
	if (argc != 3) {
		printf("Error: %s serverAddress serverPort\n", argv[0]);
		exit(1);
	}

	/* INIZIALIZZAZIONE INDIRIZZO CLIENT E SERVER */
	memset((char *) &clientAddress, 0, sizeof(struct sockaddr_in));
	clientAddress.sin_family = AF_INET;
	clientAddress.sin_addr.s_addr = INADDR_ANY;

	/* Passiamo 0 come numero di porta, con cio' ci leghiamo ad un qualsiasi
	 indirizzo libero */
	clientAddress.sin_port = 0;

	memset((char *) &serverAddress, 0, sizeof(struct sockaddr_in));
	serverAddress.sin_family = AF_INET;
	host = gethostbyname(argv[1]);
	if (host == NULL) {
		printf("%s not found in /etc/hosts", argv[1]);
		exit(2);
	} else {
		serverAddress.sin_addr.s_addr = ((struct in_addr *) (host->h_addr))->s_addr;
	}
	num = 0;
	// CONTROLLO CHE IL NUMERO DI PORTA PASSATO COME ARGOMENTO DA CONSOLE SIA UN INTERO
	while (argv[2][num] != '\0') {
		if (argv[2][num] < '0' || argv[2][num] > '9') {
			printf("Secondo argomento non intero\n");
			exit(2);
		}
		num++;
	}
	port = atoi(argv[2]);
	if (port < 1024 || port > 65535) {
		printf("Porta scorretta, range numerico sbagliato");
		exit(3);
	}
	serverAddress.sin_port = htons(port);

	printf("Select_Client_Datagram avviato...\n");

	// CREAZIONE SOCKET

	sd = socket(AF_INET, SOCK_DGRAM, 0);
	if (sd < 0) {
		perror("Apertura socket");
		exit(3);
	}
	printf("Creata la socket sd=%d", sd);

	// BIND SOCKET, a una porta scelta dal sistema

	if (bind(sd, (struct sockaddr *) &clientAddress, sizeof(clientAddress)) < 0) {
		perror("Bind socket");
		exit(3);
	}
	printf(" Client: Bind socket ok, alla porta %i\n", clientAddress.sin_port);

	/*CORPO DEL CLIENT*/
	/* Ciclo di interazione con l'utente */
	printf("\nQualsiasi tasto per procedere, EOF per terminare\n");
	printf("\nInserisci 'LV' per la percentuale dei votanti: ");
	while (gets(richiesta)) {
		if ((strcmp(richiesta, "LV")) != 0) {
			printf("\nQualsiasi tasto per procedere, EOF per terminare\n");
			printf("\nInserisci 'LV' per la percentuale dei votanti: ");
			continue;
		}

		printf("\nRichiesta del client: %s", richiesta);

		// Estraggo la lunghezza dell'indirizzo del server
		len = sizeof(serverAddress);

		// Invio del datagramma al server
		if (sendto(sd, richiesta, (strlen(richiesta) + 1), 0,
				(struct sockaddr *) &serverAddress, len) < 0) {
			perror("scrittura su socket");
			printf("\nValore in input: ");
			continue;
			// Se l'invio fallisce il client torna all'inizio del ciclo
		}
		printf("Client: richiesta inviata...\n");

		// Ricezione del risultato

		printf("\nAttesa del risultato...\n");
		if (recvfrom(sd, &risposta, sizeof(int), 0,
				(struct sockaddr *) &serverAddress, &len) < 0) {
			perror("recvfrom");
			printf("\nValore in input: ");
			continue;
			// Se questa ricezione fallisce il client torna all'inizio del ciclo
		}
		risposta = ntohl(risposta);
		printf("\nPercentuale votanti: %d\n", risposta);
		printf("\nInserisci 'LV' per la percentuale dei votanti: ");

	}
	printf("\nSelect_Client_Datagram....temino\n");
	// libero le risorse non piu' utilizzate
	close(sd);

	exit(0);
}
