// Select_Server.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#define DIM_BUFF 30
#define max(a,b) ((a) > (b) ? (a) : (b))
#define DIM_CF 17
#define N 10

// Definizione funzione per gestire il segnale SIGCHLD
void gestore(int signo) {
	int stato;
	printf("esecuzione gestore di SIGCHLD\n");
	wait(&stato);
}

typedef struct Votante {
	char cf[DIM_CF];
	char nome[DIM_BUFF];
	char cognome[DIM_BUFF];
	char password[DIM_BUFF];
	int stato;
} Votante;

int main(int argc, char * argv[]) {
	int listenfd, connfd, udpfd, nready, maxfdp1, len, nwrite;
	fd_set rset;
	const int on = 1;
	int nread, readRes, risultato, count;
	// buffer di dimensione tale da contenere CF, nome, cognome e 2 separatori (\t) e il terminatore (\0)
	char buff[DIM_CF + DIM_BUFF * 2 + 3], richiesta[DIM_BUFF], risposta[DIM_BUFF];
	char ok;
	int i, port, nVotanti, votanteLength;
	Votante elencoVotanti[N];

	struct sockaddr_in clientAddress, serverAddress;

	/* CONTROLLO ARGOMENTI ---------------------------------- */
	if (argc != 2) {
		printf("Error: %s port\n", argv[0]);
		exit(1);
	}
	// controllo per verificare che il numero di porta passato come
	// parametro sia un intero
	nread = 0;
	while (argv[1][nread] != '\0') {
		if (argv[1][nread] < '0' || argv[1][nread] > '9') {
			printf("Secondo argomento non intero\n");
			exit(2);
		}
		nread++;
	}

	port = atoi(argv[1]);
	if (port < 1024 || port > 65535) {
		printf("Porta scorretta, range numerico sbagliato");
		exit(3);
	}

	printf("\nSelect_Server avviato\n");

	/* INIZIALIZZAZIONE STRUTTURA DATI */
	strcpy(elencoVotanti[0].cf, "L");
	strcpy(elencoVotanti[0].nome, "L");
	strcpy(elencoVotanti[0].cognome, "L");
	strcpy(elencoVotanti[0].password, "L");
	elencoVotanti[0].stato = 0;
	strcpy(elencoVotanti[1].cf, "RSSMRA58E08B682G");
	strcpy(elencoVotanti[1].nome, "Mario");
	strcpy(elencoVotanti[1].cognome, "Rossi");
	strcpy(elencoVotanti[1].password, "pg875");
	elencoVotanti[1].stato = 0;
	strcpy(elencoVotanti[2].cf, "BNCLRD50S14F839T");
	strcpy(elencoVotanti[2].nome, "Alfredo");
	strcpy(elencoVotanti[2].cognome, "Bianchi");
	strcpy(elencoVotanti[2].password, "88hbgfd5");
	elencoVotanti[2].stato = 1;
	strcpy(elencoVotanti[3].cf, "BSSMRA58E08B682G");
	strcpy(elencoVotanti[3].nome, "Mario");
	strcpy(elencoVotanti[3].cognome, "Bossi");
	strcpy(elencoVotanti[3].password, "pg865");
	elencoVotanti[3].stato = 0;
	for (i = 4; i < N; i++) {
		strcpy(elencoVotanti[i].cf, "L");
		strcpy(elencoVotanti[i].nome, "L");
		strcpy(elencoVotanti[i].cognome, "L");
		strcpy(elencoVotanti[i].password, "L");
		// lo stato del voto del votante e' inizializzato a false poiche' si suppone che verra'�cambiato
		// se effettuera'� la votazione
		elencoVotanti[i].stato = 0;
	}

	/* CREAZIONE SOCKET TCP ------------------------------------------------ */
	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	if (listenfd < 0) {
		perror("apertura socket TCP ");
		exit(1);
	}
	printf("Creata la socket TCP d'ascolto, fd=%d\n", listenfd);

	/* INIZIALIZZAZIONE INDIRIZZO SERVER  */
	memset((char *) &serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = INADDR_ANY;
	serverAddress.sin_port = htons(port);

	// SETTAGGIO OPZIONI SOCKET
	if (setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0) {
		perror("set opzioni socket TCP");
		exit(2);
	}
	printf("Set opzioni socket TCP ok\n");
	// BIND SOCKET TCP
	if (bind(listenfd, (struct sockaddr *) &serverAddress, sizeof(serverAddress))
			< 0) {
		perror("bind socket TCP");
		exit(3);
	}
	printf("Bind socket TCP ok\n");
	// CREO LA CODA D'ASCOLTO PER IL SERVER
	if (listen(listenfd, 5) < 0) {
		perror("listen");
		exit(4);
	}
	printf("Listen ok\n");

	/* CREAZIONE SOCKET UDP  */
	udpfd = socket(AF_INET, SOCK_DGRAM, 0);
	if (udpfd < 0) {
		perror("apertura socket UDP");
		exit(5);
	}
	printf("Creata la socket UDP, fd=%d\n", udpfd);

	//INIZIALIZZAZIONE INDIRIZZO SERVER
	memset((char *) &serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = INADDR_ANY;
	serverAddress.sin_port = htons(port);

	//SETTAGGIO OPZIONI SOCKET
	if (setsockopt(udpfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0) {
		perror("set opzioni socket UDP");
		exit(6);
	}
	printf("Set opzioni socket UDP ok\n");
	// BIND SOCKET UDP
	if (bind(udpfd, (struct sockaddr *) &serverAddress, sizeof(serverAddress))
			< 0) {
		perror("bind socket UDP");
		exit(7);
	}
	printf("Bind socket UDP ok\n");

	// Aggancio gestore per evitare figli zombie
	signal(SIGCHLD, gestore);

	//PULIZIA E SETTAGGIO MASCHERA DEI FILE DESCRIPTOR
	FD_ZERO(&rset);
	maxfdp1 = max(listenfd,udpfd) + 1;

	// CICLO DI RICEZIONE EVENTI DELLA SELECT
	for (;;) {
		//includo nella maschera rset le posizioni di listenfd e udpfd a uno
		FD_SET(listenfd, &rset);
		FD_SET(udpfd, &rset);

		if ((nready = select(maxfdp1, &rset, NULL, NULL, NULL)) < 0) {
			if (errno == EINTR)
				continue;
			else {
				perror("select");
				exit(8);
			}
		}

		/* GESTIONE RICHIESTE*/

		//Gestione richieste da socket stream
		if (FD_ISSET(listenfd, &rset)) {
			printf("Ricevuta richiesta da Select_Client_Stream\n");
			// Lunghezze indirizzo client
			len = sizeof(struct sockaddr_in);
			// Creo una nuova connessione con il client -> nuova socket
			if ((connfd = accept(listenfd, (struct sockaddr *) &clientAddress, &len))
					< 0) {
				if (errno = EINTR)
					continue;
				else {
					perror("accept");
					exit(9);
				}
			}
			/* Generazione processo figlio */
			if (fork() == 0) {
				// Processo figlio che serve la richiesta del client
				// Chiudo la socket d'ascolto non necessaria in questa fase
				close(listenfd);
				printf("Dentro il figlio, pid=%i\n", getpid());

				// Viene generato un figlio per ogni richiesta

				nwrite = 0;
				// Accetto richieste fino alla fine del file
				while ((readRes = read(connfd, richiesta, 1)) > 0) {

					richiesta[1] = '\0';
					for (i = 0; i < N; i++) {
						if (elencoVotanti[i].stato == 0
								&& (strcmp(elencoVotanti[i].cf, "L") != 0)) {
							// Invio votante
							// Preparazione stringa di risposta
							strcpy(buff, elencoVotanti[i].cf);
							strcat(buff, "\t");
							strcat(buff, elencoVotanti[i].nome);
							strcat(buff, "\t");
							strcat(buff, elencoVotanti[i].cognome);
							votanteLength = strlen(buff);
							votanteLength = htonl(votanteLength);
							// Invio lunghezza della stringa contenente il non votante.
							if ((nwrite = write(connfd, &votanteLength, sizeof(int))) < 0) {
								perror("write");
								break;
							}
							// Invio della stringa.
							if ((nwrite = write(connfd, buff, strlen(buff))) < 0) {
								perror("write");
								break;
							}
							// Invio lunghezza zero (0) per segnalare la fine della lista.
						}
					}
					votanteLength = 0;
					votanteLength = htonl(votanteLength);
					if ((nwrite = write(connfd, &votanteLength, sizeof(int))) < 0) {
						perror("write");
						break;
					}
				} // Fine gestione richieste da socket stream
				// Libero le risorse non piu' utilizzate
				close(connfd);
				exit(0);
			} // figlio
		/* padre chiude la socket dell'operazione */
		close(connfd);
		}

		// GESTIONE RICHIESTE DA SOCKET DATAGRAM
		if (FD_ISSET(udpfd, &rset)) {

			len = sizeof(struct sockaddr_in);
			// Ricezione richiesta
			if (recvfrom(udpfd, &richiesta, sizeof(richiesta), 0,
					(struct sockaddr *) &clientAddress, &len) < 0) {
				perror("recvfrom");
				continue;
			}
			count = 0;
			nVotanti = 0;
			//Calcolo percentuale votanti
			for (i = 0; i < N; i++) {
				if ((strcmp(elencoVotanti[i].cf, "L") != 0)) {
					count++;
				}
				if ((strcmp(elencoVotanti[i].cf, "L") != 0) && elencoVotanti[i].stato
						== 1) {
					nVotanti++;
				}
			}
			risultato = (nVotanti * 100) / count; //Calcolo percentuale
			printf("count %d, nVotanti %d, percentuale %d\n", count, nVotanti,
					risultato);
			risultato = htonl(risultato);
			// Invio risultato
			if (sendto(udpfd, &risultato, sizeof(int), 0,
					(struct sockaddr *) &clientAddress, len) < 0) {
				perror("sendto");
				continue;
			}

		} // FINE GESTIONE RICHIESTE DA SOCKET DATAGRAM

	} // Ciclo for della select
	exit(0);
}

