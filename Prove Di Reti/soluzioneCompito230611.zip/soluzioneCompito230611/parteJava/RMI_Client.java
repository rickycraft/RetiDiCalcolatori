// Implementazione del Client RMI

import java.rmi.*;
import java.io.*;

class RMI_Client {

	// Avvio del Client RMI
	public static void main(String[] args) {
		int registryPort = 1099;
		String registryHost = null;
		String serviceName = "ServerRMI";
		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));

		// Controllo dei parametri della riga di comando
		if (args.length != 1 && args.length != 2) {
			System.out.println("Sintassi: ClientFile NomeHost [registryPort]");
			System.exit(1);
		} else {      
			registryHost = args[0];
			if (args.length == 2) {
				try {
          // Aggiungere anche controllo porta valida, nel range di quelle usabili
					registryPort = Integer.parseInt(args[1]);
					if (registryPort < 1024 || registryPort > 65535) {
						System.out.println("Porta scorretta");
						System.exit(2);
					}
				} catch (Exception e) {
					System.out
							.println("Sintassi: ClientFile NomeHost [registryPort], registryPort intero");
					System.exit(2);
				}
			}
		}

		// Connessione al servizio RMI remoto
		try {
			String completeName = "//" + registryHost + ":" + registryPort + "/"
					+ serviceName;
			RMI_interfaceFile serverRMI = (RMI_interfaceFile) Naming.lookup(completeName);
			System.out.println("Client RMI: Servizio \"" + serviceName
					+ "\" connesso");

			System.out.println("\nRichieste di servizio fino a fine file");

			String service;
			System.out
					.print("Servizio (I=inserisci votante, V=esprimere un voto): ");

			while ((service = stdIn.readLine()) != null) {

				if (service.equals("I")) {

					String cf, nome, cognome, passwd;
					System.out.print("CF? ");
					if( (cf = stdIn.readLine())==null ) break;
					System.out.print("nome? ");
					if( (nome = stdIn.readLine())==null ) break;
					System.out.print("cognome? ");
					if( (cognome = stdIn.readLine())==null ) break;
					System.out.print("passwd? ");
					if( (passwd = stdIn.readLine())==null ) break;
					// Invocazione remota
					try {
						int risultato = serverRMI.inserisci_votante(cf, nome, cognome, passwd);
            if( risultato<0 ) System.out.println("Problemi di inserimento.");
            else System.out.println("Inserimento andato a buon fine.");
					} catch (RemoteException re) {
						System.out.println("Errore remoto: " + re.toString());
					}

				} // C

				else if (service.equals("V")) {
					// provare a realizzare altri controlli, ad esempio
					// stringa vuota e sul CF
					String cf, passwd, voto;
					System.out.print("CF? ");
					if( (cf = stdIn.readLine())==null ) break;
					System.out.print("passwd? ");
					if( (passwd = stdIn.readLine())==null ) break;
					System.out.print("voto? ");
					while( (voto = stdIn.readLine())!=null ){
						if( voto.equals("si") || voto.equals("no") || voto.equals("nullo") ) break;
						System.out.print("voto? ");
					}
					if( voto == null) break;

					try {
						int risultato = serverRMI.esprimi_voto(cf, passwd, voto);
            if( risultato==0 ) System.out.println("Votazione andata a buon fine.");
            else if( risultato==-1 ) System.out.println("Il votante non e' fra gli aventi diritto!");
            else if( risultato==-2 ) System.out.println("Passwd non corretta!");
            else if( risultato==-3 ) System.out.println("Il votante ha gia' espresso il proprio voto!");
            else System.out.println("Altri errori (es. voto diverso da \"si\", \"no\", \"nullo\"");
					} catch (RemoteException re) {
						System.out.println("Errore remoto: " + re.toString());
					}
				} // L

				else
					System.out.println("Servizio non disponibile");

				System.out
						.print("Servizio (I=inserisci votante, V=esprimere un voto): ");
			} // !EOF

		} catch (Exception e) {
			System.err.println("ClientRMI: " + e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
	}
}