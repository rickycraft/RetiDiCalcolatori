// Interfaccia remota

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RMI_interfaceFile extends Remote {

  public int inserisci_votante(String cf, String nome, String cognome, String passwd) throws RemoteException;
  
  public int esprimi_voto(String cf, String passwd, String voto) throws RemoteException;
  
}