// Implementazione del Server

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class RMI_Server extends UnicastRemoteObject implements
		RMI_interfaceFile {

	private static final int N = 10;

	private static Votante v[] = null;

	private static int si = 0;

	private static int no = 0;

	private static int nulli = 0;

	// Costruttore
	public RMI_Server() throws RemoteException {
		super();
	}

	// Conta le occorrenze di un carattere all'interno di un file
	public synchronized int inserisci_votante(String cf, String nome,
			String cognome, String passwd) throws RemoteException {
		int primaLibera = -1;

		for (int i = 0; i < N; i++) {
			if (v[i].cf.equals(cf))
				return -1;
			if ((primaLibera < 0) && v[i].cf.equals("L"))
				primaLibera = i;
		}

		if (primaLibera < 0)
			return -1;
		else {
			v[primaLibera] = new Votante(cf, nome, cognome, passwd, false);
			return 0;
		}
	}

	// Restituisce la lista dei file il cui nome contiene car
	public synchronized int esprimi_voto(String cf, String passwd, String voto)
			throws RemoteException {
		if (!(voto.equals("si") || voto.equals("no") || voto.equals("nullo")))
			return -4;
		else {
			for (int i = 0; i < N; i++) {
				if (v[i].cf.equals(cf)) {
					if (v[i].passwd.equals(passwd)) {
						if (v[i].stato == false) {
							if (voto.equals("si"))
								si++;
							else if (voto.equals("no"))
								no++;
							else if (voto.equals("nullo"))
								nulli++;
							v[i].stato = true;
							return 0;
						} else
							return -3;
					} else
						return -2;
				}
			}
			return -1;
		}
	}

	// Avvio del Server RMI
	public static void main(String[] args) {

		// inizializzazione struttura dati
		v = new Votante[N];
		for (int i = 0; i < N; i++)
			v[i] = new Votante();
		v[1] = new Votante("RSSMRA58E08B682G", "Mario", "Rossi", "pg875", false);
		v[2] = new Votante("BNCLRD50S14F839T", "Alfredo", "Bianchi", "88hbgfd5",
				true);
		si++;

		int registryPort = 1099;
		String registryHost = "localhost";
		String serviceName = "ServerRMI";

		// Controllo dei parametri della riga di comando
		if (args.length != 0 && args.length != 1) {
			System.out.println("Sintassi: ServerImpl [registryPort]");
			System.exit(1);
		}
		if (args.length == 1) {
			try {
				registryPort = Integer.parseInt(args[0]);
				if (registryPort < 1024 || registryPort > 65535) {
					System.out.println("Porta scorretta");
					System.exit(2);
				}
			} catch (Exception e) {
				System.out
						.println("Sintassi: ServerImpl [registryPort], registryPort intero");
				System.exit(2);
			}
		}

		// Registrazione del servizio RMI
		String completeName = "//" + registryHost + ":" + registryPort + "/"
				+ serviceName;
		try {
			RMI_Server serverRMI = new RMI_Server();
			Naming.rebind(completeName, serverRMI);
			System.out.println("Server RMI: Servizio \"" + serviceName
					+ "\" registrato");
		} catch (Exception e) {
			System.err.println("Server RMI \"" + serviceName + "\": "
					+ e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
	}
}

class Votante {
	String cf;
	String nome;
	String cognome;
	String passwd;
	boolean stato;

	public Votante() {
		cf = "L";
		nome = "L";
		cognome = "L";
		passwd = "L";
		stato = false;
	}

	public Votante(String cf, String nome, String cognome, String passwd,
			boolean stato) {
		this.cf = cf;
		this.nome = nome;
		this.cognome = cognome;
		this.passwd = passwd;
		this.stato = stato;
	}

	public String toString() {
		// TODO Auto-generated method stub
		return "Votante, CF: " + cf + ", nome: " + nome + ", cognome: " + cognome
				+ ", passwd: " + passwd + ", ha votato: " + stato;
	}

}
